//
//  ZegoExpressEngine+Publisher.h
//  ZegoExpressEngine
//
//  Copyright © 2019 Zego. All rights reserved.
//

#import "ZegoExpressEngine.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZegoExpressEngine (Publisher)

/// Starts publishing a stream.
///
/// This interface allows users to publish their local audio and video streams to the ZEGO real-time audio and video cloud. Other users in the same room can use the streamID to play the audio and video streams for intercommunication.
/// Before you start to publish the stream, you need to join the room first by calling [loginRoom]. Other users in the same room can get the streamID by monitoring the [onRoomStreamUpdate] event callback after the local user publishing stream successfully.
/// In the case of poor network quality, user publish may be interrupted, and the SDK will attempt to reconnect. You can learn about the current state and error information of the stream published by monitoring the [onPublisherStateUpdate] event.
///
/// @param streamID Stream ID, a string of up to 256 characters, needs to be globally unique within the entire AppID. If in the same AppID, different users publish each stream and the stream ID is the same, which will cause the user to publish the stream failure. You cannot include URL keywords, otherwise publishing stream and playing stream will fails. Only support numbers, English characters and '~', '!', '@', '$', '%', '^', '&', '*', '(', ')', '_', '+', '=', '-', '`', ';', '’', ',', '.', '<', '>', '/', '\'.
- (void)startPublishingStream:(NSString *)streamID;

/// Starts publishing a stream (for the specified channel). You can call this API to publish a second stream.
///
/// This interface allows users to publish their local audio and video streams to the ZEGO real-time audio and video cloud. Other users in the same room can use the streamID to play the audio and video streams for intercommunication.
/// Before you start to publish the stream, you need to join the room first by calling [loginRoom]. Other users in the same room can get the streamID by monitoring the [onRoomStreamUpdate] event callback after the local user publishing stream successfully.
/// In the case of poor network quality, user publish may be interrupted, and the SDK will attempt to reconnect. You can learn about the current state and error information of the stream published by monitoring the [onPublisherStateUpdate] event.
///
/// @param streamID Stream ID, a string of up to 256 characters, needs to be globally unique within the entire AppID. If in the same AppID, different users publish each stream and the stream ID is the same, which will cause the user to publish the stream failure. You cannot include URL keywords, otherwise publishing stream and playing stream will fails. Only support numbers, English characters and '~', '!', '@', '$', '%', '^', '&', '*', '(', ')', '_', '+', '=', '-', '`', ';', '’', ',', '.', '<', '>', '/', '\'.
/// @param channel Publish stream channel
- (void)startPublishingStream:(NSString *)streamID channel:(ZegoPublishChannel)channel;

/// Stops publishing a stream.
///
/// This interface allows the user to stop sending local audio and video streams and end the call.
/// If the user has initiated publish flow, this interface must be called to stop the publish of the current stream before publishing the new stream (new streamID), otherwise the new stream publish will return a failure.
/// After stopping streaming, the developer should stop the local preview based on whether the business situation requires it.
- (void)stopPublishingStream;

/// Stops publishing a stream (for the specified channel).
///
/// This interface allows the user to stop sending local audio and video streams and end the call.
/// If the user has initiated publish flow, this interface must be called to stop the publish of the current stream before publishing the new stream (new streamID), otherwise the new stream publish will return a failure.
/// After stopping streaming, the developer should stop the local preview based on whether the business situation requires it.
/// Use this API to stop publishing stream of aux channel.
///
/// @param channel Publish stream channel
- (void)stopPublishingStream:(ZegoPublishChannel)channel;

/// Sets the extra information of the stream being published.
///
/// User this interface to set the extra info of the stream, the result will be notified via the [ZegoPublisherSetStreamExtraInfoCallback].
/// The stream extra information is an extra information identifier of the stream ID. Unlike the stream ID, which cannot be modified during the publishing process, the stream extra information can be modified midway through the stream corresponding to the stream ID.
/// Developers can synchronize variable content related to stream IDs based on stream additional information.
///
/// @param extraInfo Stream extra information, a string of up to 1024 characters.
/// @param callback Set stream extra information execution result notification
- (void)setStreamExtraInfo:(NSString *)extraInfo callback:(nullable ZegoPublisherSetStreamExtraInfoCallback)callback;

/// Sets the extra information of the stream being published (for the specified channel).
///
/// User this interface to set the extra info of the stream, the result will be notified via the [ZegoPublisherSetStreamExtraInfoCallback].
/// The stream extra information is an extra information identifier of the stream ID. Unlike the stream ID, which cannot be modified during the publishing process, the stream extra information can be modified midway through the stream corresponding to the stream ID.
/// Developers can synchronize variable content related to stream IDs based on stream additional information.
///
/// @param extraInfo Stream extra information, a string of up to 1024 characters.
/// @param channel Publish stream channel
/// @param callback Set stream extra information execution result notification
- (void)setStreamExtraInfo:(NSString *)extraInfo channel:(ZegoPublishChannel)channel callback:(nullable ZegoPublisherSetStreamExtraInfoCallback)callback;

/// Starts/Updates the local video preview.
///
/// The user can see his own local image by calling this interface. The preview function does not require you to log in to the room or publish the stream first. But after exiting the room, SDK internally actively stops previewing by default.
/// Local view and preview modes can be updated by calling this interface again.
/// You can set the mirror mode of the preview by calling the [setVideoMirrorMode] interface. The default preview setting is image mirrored.
/// When this api is called, the audio and video engine module inside SDK will start really, and it will start to try to collect audio and video. In addition to calling this api normally to preview the local screen, developers can also pass [nil] to the canvas parameter, in conjunction with ZegoExpressEngine's sound wave function, in order to achieve the purpose of detecting whether the audio equipment is working properly before logging in to the room.
///
/// @param canvas The view used to display the preview image. If the view is set to nil, no preview will be made.
- (void)startPreview:(nullable ZegoCanvas *)canvas;

/// Starts/Updates the local video preview (for the specified channel).
///
/// The user can see his own local image by calling this interface. The preview function does not require you to log in to the room or publish the stream first. But after exiting the room, SDK internally actively stops previewing by default.
/// Local view and preview modes can be updated by calling this interface again.
/// You can set the mirror mode of the preview by calling the [setVideoMirrorMode] interface. The default preview setting is image mirrored.
/// When this api is called, the audio and video engine module inside SDK will start really, and it will start to try to collect audio and video. In addition to calling this api normally to preview the local screen, developers can also pass [nil] to the canvas parameter, in conjunction with ZegoExpressEngine's sound wave function, in order to achieve the purpose of detecting whether the audio equipment is working properly before logging in to the room.
///
/// @param canvas The view used to display the preview image. If the view is set to nil, no preview will be made.
/// @param channel Publish stream channel
- (void)startPreview:(nullable ZegoCanvas *)canvas channel:(ZegoPublishChannel)channel;

/// Stops the local video preview.
///
/// This api can be called to stop previewing when there is no need to see the preview locally.
- (void)stopPreview;

/// Stops the local video preview (for the specified channel).
///
/// This api can be called to stop previewing when there is no need to see the preview locally.
///
/// @param channel Publish stream channel
- (void)stopPreview:(ZegoPublishChannel)channel;

/// Sets up the video configurations.
///
/// This api can be used to set the video frame rate, bit rate, video capture resolution, and video encoding output resolution. If you do not call this api, the default resolution is 360p, the bit rate is 600 kbps, and the frame rate is 15 fps.
/// It is necessary to set the relevant video configuration before publishing the stream or startPreview, and only support the modification of the encoding resolution and the bit rate after publishing the stream.
/// Developers should note that the wide and high resolution of the mobile end is opposite to the wide and high resolution of the PC. For example, in the case of 360p, the resolution of the mobile end is 360x640, and the resolution of the PC end is 640x360.
///
/// @param config Video configuration, the SDK provides a common setting combination of resolution, frame rate and bit rate, they also can be customized.
- (void)setVideoConfig:(ZegoVideoConfig *)config;

/// Sets up the video configurations (for the specified channel).
///
/// This api can be used to set the video frame rate, bit rate, video capture resolution, and video encoding output resolution. If you do not call this api, the default resolution is 360p, the bit rate is 600 kbps, and the frame rate is 15 fps.
/// It is necessary to set the relevant video configuration before publishing the stream, and only support the modification of the encoding resolution and the bit rate after publishing the stream.
/// Developers should note that the wide and high resolution of the mobile end is opposite to the wide and high resolution of the PC. For example, in the case of 360p, the resolution of the mobile end is 360x640, and the resolution of the PC end is 640x360.
///
/// @param config Video configuration, the SDK provides a common setting combination of resolution, frame rate and bit rate, they also can be customized.
/// @param channel Publish stream channel
- (void)setVideoConfig:(ZegoVideoConfig *)config channel:(ZegoPublishChannel)channel;

/// Gets the current video configurations.
///
/// This api can be used to get the main publish channel's current video frame rate, bit rate, video capture resolution, and video encoding output resolution.
///
/// @return Video configuration object
- (ZegoVideoConfig *)getVideoConfig;

/// Gets the current video configurations (for the specified channel).
///
/// This api can be used to get the specified publish channel's current video frame rate, bit rate, video capture resolution, and video encoding output resolution.
///
/// @param channel Publish stream channel
/// @return Video configuration object
- (ZegoVideoConfig *)getVideoConfig:(ZegoPublishChannel)channel;

/// Sets the video mirroring mode.
///
/// This interface can be called to set whether the local preview video and the published video have mirror mode enabled.
///
/// @param mirrorMode Mirror mode for previewing or publishing the stream
- (void)setVideoMirrorMode:(ZegoVideoMirrorMode)mirrorMode;

/// Sets the video mirroring mode (for the specified channel).
///
/// This interface can be called to set whether the local preview video and the published video have mirror mode enabled.
///
/// @param mirrorMode Mirror mode for previewing or publishing the stream
/// @param channel Publish stream channel
- (void)setVideoMirrorMode:(ZegoVideoMirrorMode)mirrorMode channel:(ZegoPublishChannel)channel;

#if TARGET_OS_IPHONE
/// Sets the video orientation.
///
/// This interface sets the orientation of the video. The captured image is rotated according to the value of the parameter [UIInterfaceOrientation] compared to the forward direction of the phone. After rotation, it will be automatically adjusted to adapt the encoded image resolution.
///
/// @param orientation Video orientation
- (void)setAppOrientation:(UIInterfaceOrientation)orientation;
#endif

#if TARGET_OS_IPHONE
/// Sets the video orientation (for the specified channel).
///
/// This interface sets the orientation of the video. The captured image is rotated according to the value of the parameter [UIInterfaceOrientation] compared to the forward direction of the phone. After rotation, it will be automatically adjusted to adapt the encoded image resolution.
///
/// @param orientation Video orientation
/// @param channel Publish stream channel
- (void)setAppOrientation:(UIInterfaceOrientation)orientation channel:(ZegoPublishChannel)channel;
#endif

/// Sets up the audio configurations.
///
/// You can set the combined value of the audio codec, bit rate, and audio channel through this interface. If this interface is not called, the default is standard quality mode. Should be used before publishing.
/// If the preset value cannot meet the developer's scenario, the developer can set the parameters according to the business requirements.
///
/// @param config Audio config
- (void)setAudioConfig:(ZegoAudioConfig *)config;

/// Gets the current audio configurations.
///
/// You can get the current audio codec, bit rate, and audio channel through this interface.
///
/// @return Audio config
- (ZegoAudioConfig *)getAudioConfig;

/// Stops or resumes sending the audio part of a stream.
///
/// This interface can be called when publishing the stream to publish only the video stream without publishing the audio. The SDK still collects and processes the audio, but does not send the audio data to the network. It can be set before publishing.
/// If you stop sending audio streams, the remote user that play stream of local user publishing stream can receive `Mute` status change notification by monitoring [onRemoteMicStateUpdate] callbacks,
///
/// @param mute Whether to stop sending audio streams, YES means that only the video stream is sent without sending the audio stream, and NO means that the audio and video streams are sent simultaneously. The default is NO.
- (void)mutePublishStreamAudio:(BOOL)mute;

/// Stops or resumes sending the audio part of a stream (for the specified channel).
///
/// This interface can be called when publishing the stream to publish only the video stream without publishing the audio. The SDK still collects and processes the audio, but does not send the audio data to the network. It can be set before publishing.
/// If you stop sending audio streams, the remote user that play stream of local user publishing stream can receive `Mute` status change notification by monitoring [onRemoteMicStateUpdate] callbacks,
///
/// @param mute Whether to stop sending audio streams, YES means that only the video stream is sent without sending the audio stream, and NO means that the audio and video streams are sent simultaneously. The default is NO.
/// @param channel Publish stream channel
- (void)mutePublishStreamAudio:(BOOL)mute channel:(ZegoPublishChannel)channel;

/// Stops or resumes sending the video part of a stream.
///
/// When publishing the stream, this interface can be called to publish only the audio stream without publishing the video stream. The local camera can still work normally, and can normally capture, preview and process the video picture, but does not send the video data to the network. It can be set before publishing.
/// If you stop sending video streams locally, the remote user that play stream of local user publishing stream can receive `Mute` status change notification by monitoring [onRemoteCameraStateUpdate] callbacks,
///
/// @param mute Whether to stop sending video streams, YES means that only the audio stream is sent without sending the video stream, and NO means that the audio and video streams are sent at the same time. The default is NO.
- (void)mutePublishStreamVideo:(BOOL)mute;

/// Stops or resumes sending the video part of a stream (for the specified channel).
///
/// When publishing the stream, this interface can be called to publish only the audio stream without publishing the video stream. The local camera can still work normally, and can normally capture, preview and process the video picture, but does not send the video data to the network. It can be set before publishing.
/// If you stop sending video streams locally, the remote user that play stream of local user publishing stream can receive `Mute` status change notification by monitoring [onRemoteCameraStateUpdate] callbacks,
///
/// @param mute Whether to stop sending video streams, YES means that only the audio stream is sent without sending the video stream, and NO means that the audio and video streams are sent at the same time. The default is NO.
/// @param channel Publish stream channel
- (void)mutePublishStreamVideo:(BOOL)mute channel:(ZegoPublishChannel)channel;

/// Enables or disables traffic control.
///
/// Traffic control enables SDK to dynamically adjust the bitrate of audio and video streaming according to its own and peer current network environment status.
/// Automatically adapt to the current network environment and fluctuations, so as to ensure the smooth publishing of stream.
///
/// @param enable Whether to enable traffic control. The default is ture.
/// @param property Adjustable property of traffic control, bitmask format. Should be one or the combinations of [ZegoTrafficControlProperty] enumeration. [AdaptiveFPS] as default.
- (void)enableTrafficControl:(BOOL)enable property:(ZegoTrafficControlProperty)property;

/// Sets the minimum video bitrate for traffic control.
///
/// Set how should SDK send video data when the network conditions are poor and the minimum video bitrate cannot be met.
/// When this api is not called, the SDK will automatically adjust the sent video data frames according to the current network uplink conditions by default.
///
/// @param bitrate Minimum video bitrate (kbps)
/// @param mode Video sending mode below the minimum bitrate.
- (void)setMinVideoBitrateForTrafficControl:(int)bitrate mode:(ZegoTrafficControlMinVideoBitrateMode)mode;

/// Sets the audio recording volume for stream publishing.
///
/// This interface is used to set the audio collection volume. The local user can control the volume of the audio stream sent to the far end. It can be set before publishing.
///
/// @param volume Volume percentage. The range is 0 to 200. Default value is 100.
- (void)setCaptureVolume:(int)volume;

/// Set audio capture stereo mode
///
/// This API is used to set the audio stereo capture mode. The default is mono, that is, dual channel collection is not enabled.
/// It needs to be invoked before [startPublishingStream], [startPlayingStream] or [startPreview] to take effect.
///
/// @param mode Audio stereo capture mode
- (void)setAudioCaptureStereoMode:(ZegoAudioCaptureStereoMode)mode;

/// Adds a target CDN URL to which the stream will be relayed from ZEGO's cloud streaming server.
///
/// You can call this api to publish the audio and video streams that have been published to the ZEGO real-time audio and video cloud to a custom CDN content distribution network that has high latency but supports high concurrent playing stream.
/// Because this called api is essentially a dynamic relay of the audio and video streams published to the ZEGO audio and video cloud to different CDNs, this api needs to be called after the audio and video stream is published to ZEGO real-time cloud successfully.
/// Since ZEGO's audio and video cloud service itself can be configured to support CDN(content distribution networks), this api is mainly used by developers who have CDN content distribution services themselves.
/// You can use ZEGO's CDN audio and video streaming content distribution service at the same time by calling this interface and then use the developer who owns the CDN content distribution service.
/// This interface supports dynamic relay to the CDN content distribution network, so developers can use this api as a disaster recovery solution for CDN content distribution services.
/// When the [enablePublishDirectToCDN] api is set to YES to publish the stream straight to the CDN, then calling this interface will have no effect.
///
/// @param targetURL CDN relay address, supported address format is rtmp.
/// @param streamID Stream ID
/// @param callback The execution result notification of the relay CDN operation, and proceed to the next step according to the execution result.
- (void)addPublishCdnUrl:(NSString *)targetURL streamID:(NSString *)streamID callback:(nullable ZegoPublisherUpdateCdnUrlCallback)callback;

/// Deletes the specified CDN URL, which is used for relaying streams from ZEGO's cloud streaming server to CDN.
///
/// This api is called when a CDN relayed address has been added and needs to stop propagating the stream to the CDN.
/// This api does not stop publishing audio and video stream to the ZEGO audio and video cloud.
///
/// @param targetURL CDN relay address, supported address format rtmp.
/// @param streamID Stream ID
/// @param callback Remove CDN relay result notifications
- (void)removePublishCdnUrl:(NSString *)targetURL streamID:(NSString *)streamID callback:(nullable ZegoPublisherUpdateCdnUrlCallback)callback;

/// Whether to publish streams directly from the client to CDN without passing through ZEGO's cloud streaming server.
///
/// This api needs to be set before start publishing stream.
/// After calling this api to publish the audio and video stream directly to the CDN, calling [addPublishCdnUrl] and [removePublishCdnUrl] to dynamically repost to the CDN no longer takes effect, because these two API relay or stop the audio and video stream from the ZEGO real-time audio and video cloud If it is published to CDN, if the direct audio and video stream is directly published to the CDN, the audio and video stream cannot be dynamically relay to the CDN through the ZEGO real-time audio and video cloud.
///
/// @param enable Whether to enable direct publish CDN, YES: enable direct publish CDN, NO: disable direct publish CDN
/// @param config CDN configuration, if nil, use Zego's background default configuration
- (void)enablePublishDirectToCDN:(BOOL)enable config:(nullable ZegoCDNConfig *)config;

/// Whether to publish streams directly from the client to CDN without passing through ZEGO's cloud streaming server (for the specified channel).
///
/// This api needs to be set before start publishing stream.
/// After calling this api to publish the audio and video stream directly to the CDN, calling [addPublishCdnUrl] and [removePublishCdnUrl] to dynamically repost to the CDN no longer takes effect, because these two API relay or stop the audio and video stream from the ZEGO real-time audio and video cloud If it is published to CDN, if the direct audio and video stream is directly published to the CDN, the audio and video stream cannot be dynamically relay to the CDN through the ZEGO real-time audio and video cloud.
///
/// @param enable Whether to enable direct publish CDN, YES: enable direct publish CDN, NO: disable direct publish CDN
/// @param config CDN configuration, if nil, use Zego's background default configuration
/// @param channel Publish stream channel
- (void)enablePublishDirectToCDN:(BOOL)enable config:(nullable ZegoCDNConfig *)config channel:(ZegoPublishChannel)channel;

/// Sets up the stream watermark before stream publishing.
///
/// The layout of the watermark cannot exceed the video encoding resolution of the stream. It can be set at any time before or during the publishing stream
///
/// @param watermark The upper left corner of the watermark layout is the origin of the coordinate system, and the area cannot exceed the size set by the encoding resolution. If it is nil, the watermark is cancelled.
/// @param isPreviewVisible the watermark is visible on local preview
- (void)setPublishWatermark:(nullable ZegoWatermark *)watermark isPreviewVisible:(BOOL)isPreviewVisible;

/// Sets up the stream watermark before stream publishing (for the specified channel).
///
/// The layout of the watermark cannot exceed the video encoding resolution of the stream. It can be set at any time before or during the publishing stream.
///
/// @param watermark The upper left corner of the watermark layout is the origin of the coordinate system, and the area cannot exceed the size set by the encoding resolution. If it is nil, the watermark is cancelled.
/// @param isPreviewVisible the watermark is visible on local preview
/// @param channel Publish stream channel
- (void)setPublishWatermark:(nullable ZegoWatermark *)watermark isPreviewVisible:(BOOL)isPreviewVisible channel:(ZegoPublishChannel)channel;

/// Sends Supplemental Enhancement Information.
///
/// This interface can synchronize some other additional information while the developer publishes streaming audio and video streaming data while sending streaming media enhancement supplementary information.
/// Generally, for scenarios such as synchronizing music lyrics or precise layout of video canvas, you can choose to use this api.
/// After the anchor sends the SEI, the audience can obtain the SEI content by monitoring the callback of [onPlayerRecvSEI].
/// Since SEI information follows video frames or audio frames, and because of network problems, frames may be dropped, so SEI information may also be dropped. To solve this situation, it should be sent several times within the limited frequency.
/// Limit frequency: Do not exceed 30 times per second.
/// Note: This api is effective only when there is video data published. SEI information will not be sent without publishing video data.
/// The SEI data length is limited to 4096 bytes.
///
/// @param data SEI data
- (void)sendSEI:(NSData *)data;

/// Sends Supplemental Enhancement Information (for the specified channel).
///
/// This interface can synchronize some other additional information while the developer publishes streaming audio and video streaming data while sending streaming media enhancement supplementary information.
/// Generally, for scenarios such as synchronizing music lyrics or precise layout of video canvas, you can choose to use this api.
/// After the anchor sends the SEI, the audience can obtain the SEI content by monitoring the callback of [onPlayerRecvSEI].
/// Since SEI information follows video frames or audio frames, and because of network problems, frames may be dropped, so SEI information may also be dropped. To solve this situation, it should be sent several times within the limited frequency.
/// Limit frequency: Do not exceed 30 times per second.
/// Note: This api is effective only when there is video data published. SEI information will not be sent without publishing video data.
/// The SEI data length is limited to 4096 bytes.
///
/// @param data SEI data
/// @param channel Publish stream channel
- (void)sendSEI:(NSData *)data channel:(ZegoPublishChannel)channel;

/// Enables or disables hardware encoding.
///
/// Whether to use the hardware encoding function when publishing the stream, the GPU is used to encode the stream and to reduce the CPU usage. The setting can take effect before the stream published. If it is set after the stream published, the stream should be stopped first before it takes effect.
/// Because hard-coded support is not particularly good for a few models, SDK uses software encoding by default. If the developer finds that the device is hot when publishing a high-resolution audio and video stream during testing of some models, you can consider calling this interface to enable hard coding.
///
/// @param enable Whether to enable hardware encoding, YES: enable hardware encoding, NO: disable hardware encoding
- (void)enableHardwareEncoder:(BOOL)enable;

/// Sets the timing of video scaling in the video capture workflow. You can choose to do video scaling right after video capture (the default value) or before encoding.
///
/// This interface needs to be set before previewing or streaming.
/// The main effect is whether the local preview is affected when the acquisition resolution is different from the encoding resolution.
///
/// @param mode capture scale mode
- (void)setCapturePipelineScaleMode:(ZegoCapturePipelineScaleMode)mode;

@end

NS_ASSUME_NONNULL_END
