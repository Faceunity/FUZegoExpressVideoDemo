//
//  ZegoExpressEngine+Preprocess.h
//  ZegoExpressEngine
//
//  Copyright © 2019 Zego. All rights reserved.
//

#import "ZegoExpressEngine.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZegoExpressEngine (Preprocess)

/// Enables or disables Acoustic Echo Cancellation (AEC).
///
/// Turning on echo cancellation, the SDK filters the collected audio data to reduce the echo component in the audio.
/// It needs to be invoked before [startPublishingStream], [startPlayingStream] or [startPreview] to take effect.
///
/// @param enable Whether to enable echo cancellation, YES: enable echo cancellation, NO: disable echo cancellation
- (void)enableAEC:(BOOL)enable;

/// Whether to turn on Acoustic Echo Cancellation (AEC) when using the headphone.
///
/// It needs to be invoked before [startPublishingStream], [startPlayingStream] or [startPreview] to take effect.
///
/// @param enable Whether to enable, YES: enable, NO: disable
- (void)enableHeadphoneAEC:(BOOL)enable;

/// Sets the Acoustic Echo Cancellation (AEC) mode.
///
/// Switch different echo cancellation modes to control the extent to which echo data is eliminated.
/// It needs to be invoked before [startPublishingStream], [startPlayingStream] or [startPreview] to take effect.
///
/// @param mode Echo cancellation mode
- (void)setAECMode:(ZegoAECMode)mode;

/// Enables or disables Automatic Gain Control (AGC).
///
/// When the auto gain is turned on, the sound will be amplified, but it will affect the sound quality to some extent.
/// It needs to be invoked before [startPublishingStream], [startPlayingStream] or [startPreview] to take effect.
///
/// @param enable Whether to enable automatic gain control, YES: enable AGC, NO: disable AGC
- (void)enableAGC:(BOOL)enable;

/// Enables or disables Automatic Noise Suppression (ANS).
///
/// Turning on the noise suppression switch can reduce the noise in the audio data and make the human voice clearer.
/// It needs to be invoked before [startPublishingStream], [startPlayingStream] or [startPreview] to take effect.
///
/// @param enable Whether to enable noise suppression, YES: enable AGC, NO: disable AGC
- (void)enableANS:(BOOL)enable;

/// Sets the Automatic Noise Suppression (ANS) mode.
///
/// Default is medium mode
/// It needs to be invoked before [startPublishingStream], [startPlayingStream] or [startPreview] to take effect.
///
/// @param mode Audio Noise Suppression mode
- (void)setANSMode:(ZegoANSMode)mode;

/// Enables or disables audio mixing.
///
/// Enable audio mixing, work with setAudioMixingHandler providing the audio data for mixing
///
/// @param enable Whether to enable audio mixting, YES: enable, NO: disable
- (void)enableAudioMixing:(BOOL)enable;

/// Sets up the audio mixing event handler.
///
/// @param handler Audio mixing callback handler
- (void)setAudioMixingHandler:(nullable id<ZegoAudioMixingHandler>)handler;

/// Stops or resumes playing the mixed audio locally.
///
/// When stop play audio mixing locally, the audio will not be heard on the mix side (push side) while still be heard on the remote side (pull side).
///
/// @param mute Whether to mute local audio mixting, YES: mute, NO: unmute
- (void)muteLocalAudioMixing:(BOOL)mute;

/// Sets the audio mixing output volume for both local playback and the stream to be published.
///
/// This API will modify the volume of the local playback and the mixed data that is mixed into the push stream at the same time
///
/// @param volume audio mixing volume, range from 0 to 100, 50 as default
- (void)setAudioMixingVolume:(int)volume;

/// Sets the audio mixing output volume for either local playback or the stream to published.
///
/// This API can individually set the mixing volume of local playback or the mixing volume of the push stream
///
/// @param volume audio mixing volume, range from 0 to 100, 50 as default
/// @param type volume local playback / volume in stream published
- (void)setAudioMixingVolume:(int)volume type:(ZegoVolumeType)type;

/// Enables or disables the beauty features.
///
/// The current beauty function is simple and may not meet the developer's expectations, it is recommended to use [enableCustomVideoCapture] function to connect to a third party professional beauty SDK to get the best results.
/// The [setBeautifyOption] API can be called to adjust the beauty parameters after the beauty function is enabled.
/// In the case of using a custom video capture function, because the developer has taken over the video data capturing, the SDK is no longer responsible for the video data capturing, this api is no longer valid.
///
/// @param featureBitmask Beauty features, bitmask format, you can choose to enable several features in [ZegoBeautifyFeature] at the same time
- (void)enableBeautify:(ZegoBeautifyFeature)featureBitmask;

/// Enables or disables the beauty features (for the specified channel).
///
/// The current beauty function is simple and may not meet the developer's expectations, it is recommended to use [enableCustomVideoCapture] function to connect to a third party professional beauty SDK to get the best results.
/// The [setBeautifyOption] API can be called to adjust the beauty parameters after the beauty function is enabled.
/// In the case of using a custom video capture function, because the developer has taken over the video data capturing, the SDK is no longer responsible for the video data capturing, this api is no longer valid.
///
/// @param featureBitmask Beauty features, bitmask format, you can choose to enable several features in [ZegoBeautifyFeature] at the same time
/// @param channel Publishing stream channel
- (void)enableBeautify:(ZegoBeautifyFeature)featureBitmask channel:(ZegoPublishChannel)channel;

/// Sets up the beauty parameters.
///
/// Developer need to call [enableBeautify] API first to enable the beautify function before calling this API
/// In the case of using a custom video capture function, because the developer has taken over the video data capturing, the SDK is no longer responsible for the video data capturing, this api is no longer valid.
///
/// @param option Beauty configuration options
- (void)setBeautifyOption:(ZegoBeautifyOption *)option;

/// Sets up the beauty parameters (for the specified channel).
///
/// Developer need to call [enableBeautify] API first to enable the beautify function before calling this API
/// In the case of using a custom video capture function, because the developer has taken over the video data capturing, the SDK is no longer responsible for the video data capturing, this api is no longer valid.
///
/// @param option Beauty configuration options
/// @param channel Publishing stream channel
- (void)setBeautifyOption:(ZegoBeautifyOption *)option channel:(ZegoPublishChannel)channel;

/// Set the sound equalizer (EQ)
///
/// @param bandIndex The value range is [0, 9], corresponding to 10 frequency bands, and the center frequencies are [31, 62, 125, 250, 500, 1K, 2K, 4K, 8K, 16K] Hz.
/// @param bandGain The value range is [-15, 15]. Default value is 0, if all gain values in all frequency bands are 0, EQ function will be disabled.
- (void)setAudioEqualizerGain:(int)bandIndex bandGain:(float)bandGain;

/// Sets up the voice changer parameters.
///
/// sound change effect only works on capture sounds.
///
/// @param param Voice changer parameters
- (void)setVoiceChangerParam:(ZegoVoiceChangerParam *)param;

/// Sets up the reverberation parameters.
///
/// Different values set dynamically after a successful publishing will take effect, When all of the parameters is set to 0, the reverb is turned off.
///
/// @param param Reverb parameter
- (void)setReverbParam:(ZegoReverbParam *)param;

/// Enables the virtual stereo feature.
///
/// Note: You need to set up a dual channel setAudioConfig for the virtual stereo to take effect!
///
/// @param enable YES to turn on the virtual stereo, NO to turn off the virtual stereo
/// @param angle angle of the sound source in the virtual stereo, ranging from 0 to 180, with 90 being the front, and 0 and 180 being respectively Corresponds to rightmost and leftmost, usually use 90.
- (void)enableVirtualStereo:(BOOL)enable angle:(int)angle;

@end

NS_ASSUME_NONNULL_END
